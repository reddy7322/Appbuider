# TVTelugu IPTV Pro

A native Android IPTV client for the TVTelugu token-protected M3U endpoint.

Features:
- Dynamic token login and local persistence
- Live TV, Movies, Series and Radio sections inferred from M3U metadata/groups
- Group filtering and search
- Favorites and recently watched
- Media3 playback with HLS/M3U8 support
- EPG URL discovery from `x-tvg-url`
- Android TV/D-pad friendly focusable controls
- Minimalist dark interface
- Playlist refresh and logout

Build:
`./gradlew assembleDebug`

The resulting debug APK is:
`app/build/outputs/apk/debug/app-debug.apk`

API:
`https://tvtelugu.vercel.app/api/m3u?token={token}`


## GitHub Actions
This project is configured for Java/Kotlin JVM target 17. The GitHub workflow should use JDK 17 and run:
`gradle assembleDebug --stacktrace`
