# TVTelugu IPTV – Dynamic Streaming Build

This build is optimized for the TVTelugu M3U endpoint and Android mobile + Android TV.

## Playlist

`https://tvtelugu.vercel.app/api/m3u?token={TOKEN}`

Test token supplied for development: `madtest`

Playlist requests use:

`User-Agent: IPTV`

## Playback support

Media3/ExoPlayer is configured for HLS, DASH, SmoothStreaming, RTSP and progressive media. HTTP streams use the IPTV User-Agent by default.

M3U per-stream headers are also parsed from common forms such as:

- `#EXTVLCOPT:http-user-agent=`
- `#EXTVLCOPT:http-referrer=`
- `#EXTVLCOPT:http-origin=`
- `#EXTVLCOPT:http-header=`
- URL pipe options such as `|User-Agent=...&Referer=...&Origin=...`

## Player

- Automatically switches to landscape when playback starts.
- Restores the normal orientation when leaving playback.
- Full Media3 player controller.
- Play/pause, seek bar, buffering indicator and standard playback controls.
- Previous/next channel.
- 10-second rewind and 30-second forward.
- Playback speed: 1x / 1.25x / 1.5x / 2x.
- Mute/unmute.
- Android TV DPAD channel navigation.
- Mobile touch-friendly playback.
- Keeps screen awake during playback.

## UI

- Responsive mobile layout with bottom navigation.
- Android TV layout with left navigation and DPAD focus.
- Dynamic Live TV, Movies, Series and Radio sections.
- Dynamic M3U group filtering.
- Search.
- Favorites.
- Recently watched.
- Persistent access token.
