# Build TVTelugu APK from a phone

1. Upload the contents of this project to a GitHub repository, OR upload this ZIP and use the included workflow after extraction.
2. The workflow uses JDK 17, Android SDK 35 and Gradle 8.9.
3. Run **Actions -> Build TVTelugu APK -> Run workflow**.
4. Download the **TVTelugu-APK** artifact from the completed workflow.
5. Extract the artifact and install `app-debug.apk` on Android.

The JVM-target mismatch is fixed: Java 17 and Kotlin 17 are used.
