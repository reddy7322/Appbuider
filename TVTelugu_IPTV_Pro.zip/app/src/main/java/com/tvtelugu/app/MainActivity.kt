package com.tvtelugu.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Locale

private val Context.store by preferencesDataStore("tvtelugu")
private val TOKEN_KEY = stringPreferencesKey("token")

data class Channel(
    val name: String,
    val url: String,
    val group: String = "",
    val logo: String? = null,
    val tvgId: String? = null,
    val tvgName: String? = null,
    val type: ContentType = ContentType.LIVE
)
enum class ContentType { LIVE, MOVIE, SERIES, RADIO, OTHER }

data class Playlist(val channels: List<Channel>, val epgUrl: String?)

class MainActivity : ComponentActivity() {
    private val http = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }

    @Composable
    private fun App() {
        val context = LocalContext.current
        var token by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf("") }
        var playlist by remember { mutableStateOf<Playlist?>(null) }
        var selected by remember { mutableStateOf<Channel?>(null) }
        var favorites by remember { mutableStateOf(setOf<String>()) }
        var recent by remember { mutableStateOf(listOf<String>()) }

        LaunchedEffect(Unit) {
            token = context.store.data.first()[TOKEN_KEY].orEmpty()
            if (token.isNotBlank()) {
                try { playlist = loadPlaylist(token) } catch (_: Exception) {}
            }
            loading = false
        }

        if (loading) {
            Splash()
        } else if (selected != null) {
            PlayerScreen(
                channel = selected!!,
                onBack = { selected = null },
                onNext = {
                    val list = playlist?.channels.orEmpty()
                    val i = list.indexOf(selected!!)
                    if (i >= 0 && list.isNotEmpty()) selected = list[(i + 1) % list.size]
                },
                onPrevious = {
                    val list = playlist?.channels.orEmpty()
                    val i = list.indexOf(selected!!)
                    if (i >= 0 && list.isNotEmpty()) selected = list[(i - 1 + list.size) % list.size]
                }
            )
        } else if (playlist == null) {
            Login(
                initial = token,
                error = error,
                onLogin = { t ->
                    MainScope().launch {
                        loading = true; error = ""
                        try {
                            val p = loadPlaylist(t.trim())
                            if (p.channels.isEmpty()) error = "Playlist loaded but contains no playable entries."
                            else {
                                token = t.trim()
                                context.store.edit { it[TOKEN_KEY] = token }
                                playlist = p
                            }
                        } catch (e: Exception) {
                            error = e.message ?: "Unable to load playlist."
                        }
                        loading = false
                    }
                }
            )
        } else {
            Home(
                playlist = playlist!!,
                favorites = favorites,
                recent = recent,
                onPlay = {
                    recent = (listOf(it.url) + recent.filterNot { u -> u == it.url }).take(30)
                    selected = it
                },
                onFavorite = { c ->
                    favorites = if (c.url in favorites) favorites - c.url else favorites + c.url
                },
                onRefresh = {
                    MainScope().launch {
                        try { playlist = loadPlaylist(token) } catch (e: Exception) { error = e.message ?: "Refresh failed" }
                    }
                },
                onLogout = {
                    MainScope().launch { context.store.edit { it.remove(TOKEN_KEY) } }
                    token = ""; playlist = null; favorites = emptySet(); recent = emptyList()
                }
            )
        }
    }

    private suspend fun loadPlaylist(token: String): Playlist = withContext(Dispatchers.IO) {
        val url = "https://tvtelugu.vercel.app/api/m3u?token=" + Uri.encode(token)
        val request = Request.Builder().url(url).header("User-Agent", "TVTelugu/2.0").build()
        http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) throw Exception("Playlist request failed (${r.code})")
            parseM3u(r.body?.string().orEmpty())
        }
    }

    private fun parseM3u(text: String): Playlist {
        val lines = text.lines()
        val result = mutableListOf<Channel>()
        var name = ""; var group = ""; var logo: String? = null
        var tvgId: String? = null; var tvgName: String? = null
        var epg: String? = Regex("""x-tvg-url\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.getOrNull(1)
        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("#EXTM3U", true)) {
                if (epg == null) epg = Regex("""x-tvg-url=([^\s]+)""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)?.trim('"')
            }
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",").trim().ifBlank { "Unknown" }
                group = attr(line, "group-title").orEmpty()
                logo = attr(line, "tvg-logo")
                tvgId = attr(line, "tvg-id")
                tvgName = attr(line, "tvg-name")
            } else if (line.isNotEmpty() && !line.startsWith("#") && name.isNotBlank()) {
                result += Channel(name, line, group, logo, tvgId, tvgName, classify(name, group))
                name = ""; group = ""; logo = null; tvgId = null; tvgName = null
            }
        }
        return Playlist(result, epg)
    }

    private fun attr(s: String, key: String): String? =
        Regex("""$key\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.getOrNull(1)

    private fun classify(name: String, group: String): ContentType {
        val x = "$name $group".lowercase(Locale.US)
        return when {
            listOf("radio","fm","music radio").any { x.contains(it) } -> ContentType.RADIO
            listOf("movie","cinema","vod","film").any { x.contains(it) } -> ContentType.MOVIE
            listOf("series","web series","tv series").any { x.contains(it) } -> ContentType.SERIES
            else -> ContentType.LIVE
        }
    }

    @Composable private fun Splash() {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.displaySmall)
            }
        }
    }

    @Composable private fun Login(initial: String, error: String, onLogin: (String) -> Unit) {
        var value by remember { mutableStateOf(initial) }
        val focus = remember { FocusRequester() }
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080808)) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.displayMedium)
                Text("IPTV", color = Color.Gray)
                Spacer(Modifier.height(24.dp))
                OutlinedTextField(value, { value = it }, label = { Text("Access Token") },
                    singleLine = true, modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth().focusRequester(focus))
                if (error.isNotBlank()) {
                    Spacer(Modifier.height(10.dp)); Text(error, color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onLogin(value) }, modifier = Modifier.focusable()) { Text("Continue") }
            }
        }
        LaunchedEffect(Unit) { focus.requestFocus() }
    }

    @Composable
    private fun Home(
        playlist: Playlist, favorites: Set<String>, recent: List<String>,
        onPlay: (Channel) -> Unit, onFavorite: (Channel) -> Unit,
        onRefresh: () -> Unit, onLogout: () -> Unit
    ) {
        var tab by remember { mutableStateOf(ContentType.LIVE) }
        var group by remember { mutableStateOf("All") }
        var query by remember { mutableStateOf("") }
        val allGroups = playlist.channels.filter { it.type == tab && it.group.isNotBlank() }.map { it.group }.distinct()
        val groups = listOf("All") + allGroups
        val items = playlist.channels.filter {
            it.type == tab && (group == "All" || it.group == group) &&
            (query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true))
        }

        Surface(Modifier.fillMaxSize(), color = Color(0xFF080808)) {
            Row(Modifier.fillMaxSize()) {
                Column(Modifier.width(210.dp).fillMaxHeight().padding(18.dp)) {
                    Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(22.dp))
                    listOf(
                        ContentType.LIVE to "Live TV",
                        ContentType.MOVIE to "Movies",
                        ContentType.SERIES to "Series",
                        ContentType.RADIO to "Radio"
                    ).forEach { (t, label) ->
                        NavigationButton(label, tab == t) { tab = t; group = "All" }
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationButton("Refresh", false, onRefresh)
                    NavigationButton("Logout", false, onLogout)
                }
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(when(tab) { ContentType.LIVE->"Live TV"; ContentType.MOVIE->"Movies"; ContentType.SERIES->"Series"; else->"Radio" },
                            color = Color.White, style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.weight(1f))
                        OutlinedTextField(query, { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.width(270.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        groups.forEach { g ->
                            FilterChip(selected = group == g, onClick = { group = g }, label = { Text(g) })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (items.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No content in this section", color = Color.Gray) }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            itemsIndexed(items) { _, c ->
                                Card(
                                    Modifier.fillMaxWidth().focusable().clickable { onPlay(c) },
                                    colors = CardDefaults.cardColors(Color(0xFF151515)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(c.name, color = Color.White)
                                            if (c.group.isNotBlank()) Text(c.group, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                                        }
                                        TextButton(onClick = { onFavorite(c) }) {
                                            Text(if (c.url in favorites) "★" else "☆", color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun NavigationButton(text: String, selected: Boolean, action: () -> Unit) {
        TextButton(
            onClick = action,
            modifier = Modifier.fillMaxWidth().focusable().border(
                if (selected) 1.dp else 0.dp, Color.White, RoundedCornerShape(8.dp)
            )
        ) { Text(text, color = if (selected) Color.White else Color.LightGray) }
    }

    @Composable
    private fun PlayerScreen(channel: Channel, onBack: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
        val context = LocalContext.current
        val player = remember(channel.url) {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(channel.url))
                prepare(); playWhenReady = true
            }
        }
        DisposableEffect(player) { onDispose { player.release() } }
        Surface(
            Modifier
                .fillMaxSize()
                .focusable()
                .onKeyEvent {
                    if (it.type != KeyEventType.KeyDown) return@onKeyEvent false
                    when (it.nativeKeyEvent.keyCode) {
                        android.view.KeyEvent.KEYCODE_DPAD_RIGHT,
                        android.view.KeyEvent.KEYCODE_CHANNEL_UP -> {
                            onNext()
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_LEFT,
                        android.view.KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                            onPrevious()
                            true
                        }
                        android.view.KeyEvent.KEYCODE_BACK -> {
                            onBack()
                            true
                        }
                        else -> false
                    }
                },
            color = Color.Black
        ) {
            Box(Modifier.fillMaxSize()) {
                AndroidView({ PlayerView(it).apply { this.player = player; useController = true } }, Modifier.fillMaxSize())
                Row(Modifier.align(Alignment.TopStart).padding(12.dp)) {
                    TextButton(onClick = onBack) { Text("‹ Back", color = Color.White) }
                    TextButton(onClick = onPrevious) { Text("Previous", color = Color.White) }
                    TextButton(onClick = onNext) { Text("Next", color = Color.White) }
                }
            }
        }
    }
}
