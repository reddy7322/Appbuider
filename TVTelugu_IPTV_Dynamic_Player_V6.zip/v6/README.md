# TVTelugu Core

Modern Android IPTV client for Android TV and mobile.

- Application ID: `com.tvtelugu.core`
- APK output: `tvtelugucore.apk`
- IPTV playlist User-Agent: `IPTV`
- HLS, DASH, SmoothStreaming, RTSP and progressive playback via Media3
- Automatic landscape playback
- Android TV DPAD + media remote handling, including while player is focused
- Responsive minimalist Material 3 UI
- HTTP/HTTPS stream support

Build through GitHub Actions. The workflow uploads a directly named `tvtelugucore.apk` artifact.
