# TVTelugu Core V6

Upload `TVTelugu_IPTV_Dynamic_Player_V6.zip` to the Appbuider repository and run **Build TVTelugu APK**.
The workflow produces `tvtelugucore.apk`.

Package: `com.tvtelugu.core`
Version: 6.0 (versionCode 6)
