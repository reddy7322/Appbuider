package com.tvtelugu.core

import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Locale

private val Context.store by preferencesDataStore("tvtelugu")
private val TOKEN_KEY = stringPreferencesKey("token")

private const val DEFAULT_UA = "IPTV"

data class Channel(
    val name: String,
    val url: String,
    val group: String = "",
    val logo: String? = null,
    val tvgId: String? = null,
    val tvgName: String? = null,
    val type: ContentType = ContentType.LIVE,
    val headers: Map<String, String> = emptyMap()
)

enum class ContentType { LIVE, MOVIE, SERIES, RADIO, OTHER }
data class Playlist(val channels: List<Channel>, val epgUrl: String?)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private val http = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }

    @Composable
    private fun App() {
        val context = LocalContext.current
        var token by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf("") }
        var playlist by remember { mutableStateOf<Playlist?>(null) }
        var selected by remember { mutableStateOf<Channel?>(null) }
        var favorites by remember { mutableStateOf(setOf<String>()) }
        var recent by remember { mutableStateOf(listOf<String>()) }

        LaunchedEffect(Unit) {
            token = context.store.data.first()[TOKEN_KEY].orEmpty()
            if (token.isNotBlank()) {
                try { playlist = loadPlaylist(token) } catch (e: Exception) { error = e.message.orEmpty() }
            }
            loading = false
        }

        when {
            loading -> Splash()
            selected != null -> PlayerScreen(
                channel = selected!!,
                onBack = { selected = null },
                onNext = {
                    val list = playlist?.channels.orEmpty()
                    val i = list.indexOfFirst { it.url == selected?.url }
                    if (i >= 0 && list.isNotEmpty()) selected = list[(i + 1) % list.size]
                },
                onPrevious = {
                    val list = playlist?.channels.orEmpty()
                    val i = list.indexOfFirst { it.url == selected?.url }
                    if (i >= 0 && list.isNotEmpty()) selected = list[(i - 1 + list.size) % list.size]
                }
            )
            playlist == null -> Login(
                initial = token,
                error = error,
                onLogin = { t ->
                    MainScope().launch {
                        loading = true; error = ""
                        try {
                            val clean = t.trim()
                            val p = loadPlaylist(clean)
                            if (p.channels.isEmpty()) error = "Playlist loaded but contains no playable entries."
                            else {
                                token = clean
                                context.store.edit { it[TOKEN_KEY] = clean }
                                playlist = p
                            }
                        } catch (e: Exception) { error = e.message ?: "Unable to load playlist." }
                        loading = false
                    }
                }
            )
            else -> Home(
                playlist = playlist!!,
                favorites = favorites,
                recent = recent,
                onPlay = {
                    recent = (listOf(it.url) + recent.filterNot { u -> u == it.url }).take(30)
                    selected = it
                },
                onFavorite = { c -> favorites = if (c.url in favorites) favorites - c.url else favorites + c.url },
                onRefresh = {
                    MainScope().launch {
                        try { playlist = loadPlaylist(token); error = "" } catch (e: Exception) { error = e.message ?: "Refresh failed" }
                    }
                },
                onLogout = {
                    MainScope().launch { context.store.edit { it.remove(TOKEN_KEY) } }
                    token = ""; playlist = null; favorites = emptySet(); recent = emptyList()
                }
            )
        }
    }

    private suspend fun loadPlaylist(token: String): Playlist = withContext(Dispatchers.IO) {
        val url = "https://tvtelugu.vercel.app/api/m3u?token=" + android.net.Uri.encode(token)
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", DEFAULT_UA)
            .header("Accept", "application/x-mpegURL, application/vnd.apple.mpegurl, audio/mpegurl, text/plain, */*")
            .header("Cache-Control", "no-cache")
            .build()
        http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) throw Exception("Playlist request failed (${r.code}) — User-Agent: $DEFAULT_UA")
            parseM3u(r.body?.string().orEmpty())
        }
    }

    private fun parseM3u(text: String): Playlist {
        val result = mutableListOf<Channel>()
        var name = ""; var group = ""; var logo: String? = null
        var tvgId: String? = null; var tvgName: String? = null
        var pendingHeaders = linkedMapOf<String, String>()
        var epg = Regex("""x-tvg-url\s*=\s*[\"']([^\"']+)[\"']""", RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)

        fun resetEntry() {
            name = ""; group = ""; logo = null; tvgId = null; tvgName = null; pendingHeaders = linkedMapOf()
        }

        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isBlank()) continue
            if (line.startsWith("#EXTM3U", true)) {
                if (epg == null) epg = Regex("""x-tvg-url=([^\s]+)""", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.trim('"', '\'')
                continue
            }
            if (line.startsWith("#EXTINF", true)) {
                val comma = line.indexOf(',')
                name = if (comma >= 0) line.substring(comma + 1).trim().ifBlank { "Unknown" } else "Unknown"
                group = attr(line, "group-title").orEmpty()
                logo = attr(line, "tvg-logo")
                tvgId = attr(line, "tvg-id")
                tvgName = attr(line, "tvg-name")
                continue
            }
            if (line.startsWith("#EXTVLCOPT:", true) || line.startsWith("#EXTHTTP:", true)) {
                val kv = line.substringAfter(':').split('=', limit = 2)
                if (kv.size == 2) {
                    val key = kv[0].trim().lowercase(Locale.US)
                    val value = kv[1].trim().trim('"', '\'')
                    when {
                        key.contains("user-agent") -> pendingHeaders["User-Agent"] = value
                        key.contains("referrer") || key == "http-referrer" -> pendingHeaders["Referer"] = value
                        key.contains("origin") -> pendingHeaders["Origin"] = value
                        key == "http-header" -> value.split(':', limit = 2).takeIf { it.size == 2 }?.let { pendingHeaders[it[0].trim()] = it[1].trim() }
                    }
                }
                continue
            }
            if (line.startsWith("#KODIPROP", true) || line.startsWith("#EXTGRP", true) || line.startsWith("#EXT-X-", true)) continue
            if (!line.startsWith("#") && name.isNotBlank()) {
                var streamUrl = line
                val pipe = streamUrl.indexOf('|')
                if (pipe >= 0) {
                    val base = streamUrl.substring(0, pipe)
                    val opts = streamUrl.substring(pipe + 1)
                    streamUrl = base
                    opts.split('&').forEach { part ->
                        val p = part.split('=', limit = 2)
                        if (p.size == 2) {
                            val k = p[0].trim().lowercase(Locale.US)
                            val v = java.net.URLDecoder.decode(p[1].trim(), "UTF-8")
                            when {
                                k == "user-agent" || k == "http-user-agent" -> pendingHeaders["User-Agent"] = v
                                k == "referer" || k == "http-referrer" -> pendingHeaders["Referer"] = v
                                k == "origin" -> pendingHeaders["Origin"] = v
                                k == "cookie" -> pendingHeaders["Cookie"] = v
                            }
                        }
                    }
                }
                result += Channel(name, streamUrl, group, logo, tvgId, tvgName, classify(name, group), pendingHeaders.toMap())
                resetEntry()
            }
        }
        return Playlist(result.distinctBy { it.url }, epg)
    }

    private fun attr(s: String, key: String): String? =
        Regex("""$key\s*=\s*[\"']([^\"']*)[\"']""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.getOrNull(1)

    private fun classify(name: String, group: String): ContentType {
        val x = "$name $group".lowercase(Locale.US)
        return when {
            listOf("radio", " fm", "fm ", "music radio", "podcast").any { x.contains(it) } -> ContentType.RADIO
            listOf("movie", "cinema", "vod", "film").any { x.contains(it) } -> ContentType.MOVIE
            listOf("series", "web series", "tv series", "episode").any { x.contains(it) } -> ContentType.SERIES
            else -> ContentType.LIVE
        }
    }

    @Composable private fun Splash() {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.displaySmall)
                    Text("IPTV", color = Color.Gray)
                    Spacer(Modifier.height(16.dp)); CircularProgressIndicator()
                }
            }
        }
    }

    @Composable
    private fun Login(initial: String, error: String, onLogin: (String) -> Unit) {
        var value by remember { mutableStateOf(initial) }
        val focus = remember { FocusRequester() }
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080808)) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(Modifier.widthIn(max = 600.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.displayMedium)
                    Text("IPTV", color = Color.Gray)
                    Spacer(Modifier.height(24.dp))
                    OutlinedTextField(value, { value = it }, label = { Text("Access Token") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth().focusRequester(focus))
                    if (error.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(error, color = MaterialTheme.colorScheme.error) }
                    Spacer(Modifier.height(18.dp))
                    Button(enabled = value.isNotBlank(), onClick = { onLogin(value) }, modifier = Modifier.focusable()) { Text("Continue") }
                }
            }
        }
        LaunchedEffect(Unit) { focus.requestFocus() }
    }

    @Composable
    private fun Home(
        playlist: Playlist, favorites: Set<String>, recent: List<String>,
        onPlay: (Channel) -> Unit, onFavorite: (Channel) -> Unit,
        onRefresh: () -> Unit, onLogout: () -> Unit
    ) {
        var tab by remember { mutableStateOf(ContentType.LIVE) }
        var group by remember { mutableStateOf("All") }
        var query by remember { mutableStateOf("") }
        val allGroups = playlist.channels.filter { it.type == tab && it.group.isNotBlank() }.map { it.group }.distinct()
        val groups = listOf("All") + allGroups
        val items = playlist.channels.filter {
            it.type == tab && (group == "All" || it.group == group) &&
                (query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true))
        }
        val recentItems = remember(playlist.channels, recent) { recent.mapNotNull { u -> playlist.channels.find { it.url == u } } }
        val favoriteItems = playlist.channels.filter { it.url in favorites }

        Surface(Modifier.fillMaxSize(), color = Color(0xFF080808)) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val compact = maxWidth < 700.dp
                if (compact) {
                    Column(Modifier.fillMaxSize()) {
                        HomeContent(tab, query, { query = it }, groups, group, { group = it }, items, favorites, onPlay, onFavorite,
                            recentItems, favoriteItems)
                        NavigationBar(containerColor = Color(0xFF101010)) {
                            listOf(ContentType.LIVE to "Live", ContentType.MOVIE to "Movies", ContentType.SERIES to "Series", ContentType.RADIO to "Radio").forEach { (t, label) ->
                                NavigationBarItem(selected = tab == t, onClick = { tab = t; group = "All" }, icon = { Text(label.take(1)) }, label = { Text(label) })
                            }
                        }
                    }
                } else {
                    Row(Modifier.fillMaxSize()) {
                        Column(Modifier.width(210.dp).fillMaxHeight().padding(18.dp)) {
                            Text("TVTelugu", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(22.dp))
                            listOf(ContentType.LIVE to "Live TV", ContentType.MOVIE to "Movies", ContentType.SERIES to "Series", ContentType.RADIO to "Radio").forEach { (t, label) ->
                                NavigationButton(label, tab == t) { tab = t; group = "All" }
                            }
                            Spacer(Modifier.weight(1f)); NavigationButton("Refresh", false, onRefresh); NavigationButton("Logout", false, onLogout)
                        }
                        HomeContent(tab, query, { query = it }, groups, group, { group = it }, items, favorites, onPlay, onFavorite,
                            recentItems, favoriteItems, Modifier.weight(1f))
                    }
                }
            }
        }
    }

    @Composable
    private fun HomeContent(
        tab: ContentType, query: String, onQuery: (String) -> Unit, groups: List<String>, group: String, onGroup: (String) -> Unit,
        items: List<Channel>, favorites: Set<String>, onPlay: (Channel) -> Unit, onFavorite: (Channel) -> Unit,
        recentItems: List<Channel>, favoriteItems: List<Channel>, modifier: Modifier = Modifier
    ) {
        Column(modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(when (tab) { ContentType.LIVE -> "Live TV"; ContentType.MOVIE -> "Movies"; ContentType.SERIES -> "Series"; else -> "Radio" }, color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.weight(1f))
                OutlinedTextField(query, onQuery, label = { Text("Search") }, singleLine = true, modifier = Modifier.widthIn(min = 180.dp, max = 320.dp))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                groups.forEach { g -> FilterChip(selected = group == g, onClick = { onGroup(g) }, label = { Text(g, maxLines = 1) }) }
            }
            Spacer(Modifier.height(10.dp))
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No content in this section", color = Color.Gray) }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    if (recentItems.isNotEmpty() && query.isBlank() && group == "All") {
                        item { Text("Recently Watched", color = Color.White, style = MaterialTheme.typography.titleMedium) }
                        items(recentItems.take(8), key = { "recent-${it.url}" }) { ChannelCard(it, favorites, onPlay, onFavorite) }
                        item { Spacer(Modifier.height(8.dp)); Text("All Channels", color = Color.White, style = MaterialTheme.typography.titleMedium) }
                    }
                    if (favoriteItems.isNotEmpty() && query.isBlank() && group == "All") {
                        item { Text("Favorites", color = Color.White, style = MaterialTheme.typography.titleMedium) }
                        items(favoriteItems.take(8), key = { "fav-${it.url}" }) { ChannelCard(it, favorites, onPlay, onFavorite) }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                    items(items, key = { it.url }) { c -> ChannelCard(c, favorites, onPlay, onFavorite) }
                }
            }
        }
    }

    @Composable private fun ChannelCard(c: Channel, favorites: Set<String>, onPlay: (Channel) -> Unit, onFavorite: (Channel) -> Unit) {
        Card(Modifier.fillMaxWidth().focusable().clickable { onPlay(c) }, colors = CardDefaults.cardColors(Color(0xFF121217)), shape = RoundedCornerShape(14.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF242424), RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
                    Text(c.name.take(1).uppercase(), color = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, color = Color.White, maxLines = 1)
                    if (c.group.isNotBlank()) Text(c.group, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
                TextButton(onClick = { onFavorite(c) }) { Text(if (c.url in favorites) "★" else "☆", color = Color.White) }
            }
        }
    }

    @Composable private fun NavigationButton(text: String, selected: Boolean, action: () -> Unit) {
        TextButton(onClick = action, modifier = Modifier.fillMaxWidth().focusable().border(if (selected) 1.dp else 0.dp, Color.White, RoundedCornerShape(8.dp))) {
            Text(text, color = if (selected) Color.White else Color.LightGray)
        }
    }

    @OptIn(UnstableApi::class)
    @Composable
    private fun PlayerScreen(channel: Channel, onBack: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit) {
        val context = LocalContext.current
        val activity = context as? MainActivity
        var errorMessage by remember(channel.url) { mutableStateOf("") }
        var muted by remember(channel.url) { mutableStateOf(false) }
        var speed by remember(channel.url) { mutableStateOf(1f) }

        LaunchedEffect(channel.url) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            WindowInsetsControllerCompat(activity.window, activity.window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        val player = remember(channel.url, channel.headers) {
            val headers = linkedMapOf<String, String>("User-Agent" to DEFAULT_UA)
            headers.putAll(channel.headers)
            val httpDataSource = DefaultHttpDataSource.Factory()
                .setDefaultRequestProperties(headers)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000)
            // DefaultDataSource keeps HTTP playback while also allowing non-HTTP schemes
            // supported by Media3 (for example RTSP via the RTSP extension).
            val dataSource = DefaultDataSource.Factory(context, httpDataSource)
            val mediaSourceFactory = DefaultMediaSourceFactory(context).setDataSourceFactory(dataSource)
            val mediaItemBuilder = MediaItem.Builder().setUri(channel.url)
            val lowerUrl = channel.url.lowercase(Locale.US)
            when {
                lowerUrl.contains(".m3u8") || lowerUrl.contains("/hls") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
                lowerUrl.contains(".mpd") || lowerUrl.contains("/dash") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
                lowerUrl.contains(".ism/manifest") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_SS_MANIFEST)
            }
            ExoPlayer.Builder(context).setMediaSourceFactory(mediaSourceFactory).build().apply {
                setMediaItem(mediaItemBuilder.build())
                addListener(object : androidx.media3.common.Player.Listener {
                    override fun onPlayerError(error: PlaybackException) { errorMessage = "Playback failed: ${error.errorCodeName}" }
                })
                prepare(); playWhenReady = true
            }
        }

        DisposableEffect(player) {
            onDispose {
                player.release()
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowInsetsControllerCompat(activity.window, activity.window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }

        BackHandler(enabled = true) { onBack() }

        Surface(Modifier.fillMaxSize().background(Color.Black).focusable().onKeyEvent {
            if (it.type != KeyEventType.KeyDown) return@onKeyEvent false
            when (it.nativeKeyEvent.keyCode) {
                android.view.KeyEvent.KEYCODE_CHANNEL_UP, android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> { onNext(); true }
                android.view.KeyEvent.KEYCODE_CHANNEL_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { onPrevious(); true }
                android.view.KeyEvent.KEYCODE_BACK -> { onBack(); true }
                android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { player.playWhenReady = !player.isPlaying; true }
                else -> false
            }
        }, color = Color.Black) {
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { PlayerView(it).apply {
                        this.player = player
                        useController = true
                        controllerShowTimeoutMs = 5000
                        controllerHideOnTouch = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        keepScreenOn = true
                        setUseArtwork(false)
                        isFocusable = true
                        isFocusableInTouchMode = true
                        requestFocus()
                        setOnKeyListener { _, keyCode, event ->
                            if (event.action != android.view.KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                            when (keyCode) {
                                android.view.KeyEvent.KEYCODE_CHANNEL_UP, android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> { onNext(); true }
                                android.view.KeyEvent.KEYCODE_CHANNEL_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { onPrevious(); true }
                                android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { player.playWhenReady = !player.isPlaying; true }
                                android.view.KeyEvent.KEYCODE_BACK -> { onBack(); true }
                                else -> false
                            }
                        }
                    } },
                    update = { it.player = player },
                    modifier = Modifier.fillMaxSize()
                )

                Row(Modifier.align(Alignment.TopStart).padding(10.dp).background(Color(0x88000000), RoundedCornerShape(8.dp))) {
                    TextButton(onClick = onBack) { Text("‹ Back", color = Color.White) }
                    TextButton(onClick = onPrevious) { Text("Previous", color = Color.White) }
                    TextButton(onClick = onNext) { Text("Next", color = Color.White) }
                }

                Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(channel.name, color = Color.White, style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.background(Color(0x99000000), RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 5.dp))
                    Row(horizontalArrangement = Arrangement.Center) {
                        AssistChip(onClick = { player.seekBack() }, label = { Text("−10s") })
                        Spacer(Modifier.width(6.dp))
                        AssistChip(onClick = { player.seekForward() }, label = { Text("+30s") })
                        Spacer(Modifier.width(6.dp))
                        AssistChip(onClick = {
                            val next = when (speed) { 1f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 2f; else -> 1f }
                            speed = next; player.setPlaybackSpeed(next)
                        }, label = { Text("${speed}x") })
                        Spacer(Modifier.width(6.dp))
                        AssistChip(onClick = { muted = !muted; player.volume = if (muted) 0f else 1f }, label = { Text(if (muted) "Unmute" else "Mute") })
                    }
                }
                if (errorMessage.isNotBlank()) {
                    Text(errorMessage, color = Color.White, modifier = Modifier.align(Alignment.Center).background(Color(0xCC8B0000), RoundedCornerShape(8.dp)).padding(14.dp))
                }
            }
        }
    }
}
